package com.antioffbrand.genuinescanner;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.Buffer;

public class ContentFetcher extends AsyncTask<Void, Void, String> {
    URL url = new URL("https://stoneevens.github.io/test.txt");

    public ContentFetcher() throws MalformedURLException {
    }

    public String fetchContent() {
        return doInBackground();
    }


    @Override
    protected String doInBackground(Void... voids) {
        String line = new String();

        try {
            URLConnection conn = url.openConnection();
            InputStream is = conn.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            if ((line = br.readLine()) != null) {
                return line;
            }

            br.close();
        } catch (Exception e) {

        }
        return line;
    }
}
