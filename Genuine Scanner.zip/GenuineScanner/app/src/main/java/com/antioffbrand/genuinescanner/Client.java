package com.antioffbrand.genuinescanner;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Queue;

public class Client{
    private Socket socket;
    private DataInputStream dis;
    private DataOutputStream dos;
    private Queue<String> input;
    private String output;
    private Boolean connected;



    public Client() {
        connected = true;
        getConnection();
    }

    public void getConnection() {
        Log.i("Response", "Called getConnection");
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                connected = true;

                try {
                    socket = new Socket("192.168.168.124", 800);

                    dis = new DataInputStream(socket.getInputStream());
                    dos = new DataOutputStream(socket.getOutputStream());

                    input = new LinkedList<String>();
                    output = new String("Good");

                    while (connected) {
                        if (!output.equals("")) {
                            dos.writeUTF(output);
                            dos.flush();
                        }

                        String s;
                        while (!(s = dis.readUTF()).toString().equals("")) {
                            input.add(s);
                        }
                    }
                } catch (IOException e) {
                    Log.i("Catch Disconnection", "Client Disconnected");
                    connected = false;
                    try {
                        socket.close();
                    } catch (IOException ex) {

                    } catch (NullPointerException e2) {

                    }
                }
            }
        });

        thread.start();
    }
    public String getString(String output) throws IOException {
        if (!input.isEmpty()) {
            return input.poll();
        }

        this.output = output;

        Log.i("User Input", this.output);
        return "";
    }

    public String getConnected() {
        return connected.toString();
    }
}


